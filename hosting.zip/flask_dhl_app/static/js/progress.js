var delivered = {{ delivered|tojson }};
