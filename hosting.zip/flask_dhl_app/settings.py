import os


DHL_API_KEY = os.environ.get('DHL_API_KEY')
ACCEPT = os.environ.get('ACCEPT')
